/* clientsocket.h */
#ifndef _CLIENTSOCKET_H
#define _CLIENTSOCKET_H

int raw_socket(int ifindex);

#endif
